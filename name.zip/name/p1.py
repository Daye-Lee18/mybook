class Solution:
    def judgeCircle(self, moves: str) -> bool:    