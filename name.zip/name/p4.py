from typing import List 

class Solution:
    def minCostClimbingStairs(self, cost: List[int]) -> int:
        